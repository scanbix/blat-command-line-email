# blat-command-line-email
Example call of blat.exe focusing on unicode support.
